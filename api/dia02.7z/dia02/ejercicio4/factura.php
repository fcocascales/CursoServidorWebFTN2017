<?php

  $factura = array(
    'numero'=> "1001",
    'cliente'=> "ACME, S.A.",
    'fecha'=> "2017-04-24",
    'iva'=> 0.21,
    'detalles'=> array(
      array(
        'producto'=> "Sofá",
        'unidades'=> 1,
        'precio'=> 300
      ),
      array(
        'producto'=> "Silla",
        'unidades'=> 4,
        'precio'=> 39
      )
    )
  );
