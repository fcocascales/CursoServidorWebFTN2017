Ejercicio 5
===========

Obtener los datos de un archivo XML o JSON.
Usaremos código PHP.

  - "factura.json" --> "factura.json.php"
  - "factura.xml" --> "factura.xml.php"
