<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ejercicio 5</title>
</head>
<body>
  <h1>Ejercicio 5</h1>
  <p>
    <a href="ejercicio5.md">Enunciado</a>
  </p>
  <h2>Solución</h2>
  <ul>
    <!--li><a href="factura.php">factura.php</a> con la estructura de datos arriba descrita</li-->
    <li><a href="factura.json">factura.json</a> Origen JSON</li>
    <li><a href="factura.json.php">factura.json.php</a> Leer JSON con la función <strong>json_decode</strong></li>
    <li><a href="factura.xml">factura1.xml</a> Origen XML</li>
    <li><a href="factura.xml.php">factura1.xml.php</a> Leer JSON con la clase <strong>SimpleXMLElement</strong></li>
  </ul>
</body>
</html>
