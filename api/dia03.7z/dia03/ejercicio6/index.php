<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ejercicio 6</title>
</head>
<body>
  <h1>Ejercicio 6</h1>
  <p>
    <a href="ejercicio6.md">Enunciado</a>
  </p>
  <h2>Solución</h2>
  <ul>
    <li><a href="clima.xml">clima.xml</a></li>
    <li><a href="sevilla.php">sevilla.php</a></li>
    <li><a href="clima.php">clima.php</a></li>
  </ul>
</body>
</html>
