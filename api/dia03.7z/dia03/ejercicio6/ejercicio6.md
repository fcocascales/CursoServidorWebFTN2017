Ejercicio 6
===========

Dado el siguiente archivo XML:

```xml
    <?xml version="1.0" encoding="UTF-8"?>
    <clima>
      <ciudad min_temp="15" max_temp="23">Barcelona</ciudad>
      <ciudad min_temp="18" max_temp="26">Sevilla</ciudad>
      <ciudad min_temp="11" max_temp="14">Bilbao</ciudad>
      <ciudad min_temp="16" max_temp="24">Valencia</ciudad>
    </clima>
```    

Haz lo siguiente:
  - Guarda el archivo anterior como **clima.xml**
  - Realiza la página **sevilla.php** que indique la temperatura mínima y máxima a partir de la información contenida en el archivo XML.
  - Realiza un formulario **clima.php** con un desplegable de las ciudades. Al enviar el formulario debe indicar la temperatura mínima y máxima de la ciudad seleccionada.
