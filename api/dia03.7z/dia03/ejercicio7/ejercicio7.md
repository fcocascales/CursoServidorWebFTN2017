Ejercicio 7
===========

Dado el siguiente archivo JSON:

```json
    [
      {
        "fecha": "2017-04-24",
        "hora": "09:00",
        "tarea": "Visita cliente"
      },
      {
        "fecha": "2017-04-25",
        "hora": "11:00",
        "tarea": "Avituallamiento"
      },
      {
        "fecha": "2017-04-26",
        "hora": "10:30",
        "tarea": "Mantenimiento"
      },
      {
        "fecha": "2017-04-27",
        "hora": "17:00",
        "tarea": "Copia respaldo"
      },
      {
        "fecha": "2017-04-28",
        "hora": "14:15",
        "tarea": "Refactorización"
      }
    ]
```    

Haz lo siguiente:
  - Guárdalo el archivo anterior como **semana.json**
  - Crea el archivo **martes.php** que muestre la fecha, la hora y la tarea que hay que realizar el martes.
  - Crea un formulario en el archivo **semana.php** que muestre un desplegable de las tareas. Al enviar el formulario debe indicar la fecha y hora de la tarea seleccionada.
