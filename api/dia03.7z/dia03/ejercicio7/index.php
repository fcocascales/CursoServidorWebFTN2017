<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ejercicio 7</title>
</head>
<body>
  <h1>Ejercicio 7</h1>
  <p>
    <a href="ejercicio7.md">Enunciado</a>
  </p>
  <h2>Solución</h2>
  <ul>
    <li><a href="semana.json">semana.json</a></li>
    <li><a href="martes.php">martes.php</a></li>
    <li><a href="semana.php">semana.php</a></li>
  </ul>
</body>
</html>
