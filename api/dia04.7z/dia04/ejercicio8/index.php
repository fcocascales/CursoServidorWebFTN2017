<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ejercicio 8</title>
</head>
<body>
  <h1>Ejercicio 8</h1>
  <p>
    <a href="ejercicio8.md">Enunciado</a>
  </p>
  <h2>Solución</h2>
  <ul>
    <li><a href="7183.xml">7183.xml</a> obtenido de TuTiempo.net</li>
    <li><a href="horas.php">horas.php</a> solución</li>
    <li><a href="horas2.php">horas2.php</a> tiene en cuenta hora de hoy o de mañana</li>
    <li><a href="dias.php">dias.php</a></li>
  </ul>
</body>
</html>
