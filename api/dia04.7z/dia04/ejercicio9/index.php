<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ejercicio 9</title>
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body>
  <div id="image"></div>
  <div id="fondo"></div>
  <h1>Ejercicio 9 <img src="styles/feed_icon.png"></h1>
  <p>
    <a href="ejercicio9.md">Enunciado</a>
  </p>
  <h2>Solución</h2>
  <ul>
    <li><a href="blogs.php">blogs.php</a></li>
  </ul>
</body>
</html>
