<?php

  $feeds = array(
    'Creadictos'=> "http://www.creadictos.com/feed/",
    'LineaDeCodigo'=> "http://lineadecodigo.com/feed/",
    'LaWebera'=> "http://feeds.feedburner.com/laweberaes?format=xml",
    'MedulaPagana'=> "http://medulapagana.blogspot.es/rss2.xml",
    'ElPeriodico'=> "http://www.elperiodico.com/es/rss/ciencia/rss.xml",
    'MarketingAndWeb'=> "http://www.marketingandweb.es/feed",
    "ProInf"=> "http://proinf.net/feed/rss_news",
  );
