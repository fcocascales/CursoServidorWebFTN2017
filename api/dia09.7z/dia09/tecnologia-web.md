Tecnología web
==============

  - **AJAX** !!!

    Peticiones al servidor realizadas desde Javascript

  - **jQuery** !!!

    Framework que simplifica el uso de Javascript

  - **AngularJS**

    Extensión de HTML

  - **Python**

    Lenguaje que se puede usar en el servidor en vez del PHP.
    Es sencillo de aprender y potente.

  - **Bootstrap**

    Framework de CSS.

  - **MongoDB**

    Base de datos no-sql. Base de datos para aplicaciones en la nube.

  - **EngiNX**

    Servidor web que se podría usar en vez del Apache. Es rápido.

  - **NodeJS**

    Servidor web que se programa con Javascript. El Apache se programa con PHP.

  - **Git** y **GIThub** !!!

    Sistema de control de versiones distribuidos.
    Sincronizar el código fuente dentro de un grupo de trabajo.

  - **CMS** Content Management System

    - WordPress - Blogs. Tiene muchos plugin
    - Drupal - Web flexible.
    - Joomla - Web de cualquier tipo de web.
    - PrestaShop - Tienda online
    - etc.

  - **Framework MVC** (Modelo Vista Controlador)

    - Laravel - PHP
    - Symphony - PHP
    - Ruby on Rails - Ruby
    - etc.
