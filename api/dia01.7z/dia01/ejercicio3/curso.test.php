<?php
  require_once "curso.php";

  header("Content-Type: text/plain");

  print_r($curso); // Imprime el array

  //var_dump($curso); // Da más información que print_r

?>
