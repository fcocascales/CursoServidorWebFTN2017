<?php
  $curso = array(
    'profesor'=> "Francisco",
    'alumnos'=> array(
      "Toni", "Barlan", "David", "Emilio",
      "Jordi", "Marta", "Sergio", "Víctor"
    ),
    'aula'=> 11,
    'ordenadores'=> 21,
    'horario'=> array(
      'dias'=> array(
        "lun", "mar", "mié", "jue", "vie"
      ),
      'hora_inicio'=> "9:00",
      'hora_final'=> "14:00"
    )
  );
?>
