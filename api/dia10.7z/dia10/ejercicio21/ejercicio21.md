Ejercicio 21
============

Copiar todos los ficheros del ejercicio anterior

El "test_client.php" envía en el contenido un json con los datos "operando1" y "operando2".

Modifica la url del "test_client.php" para que apunte al "test_server.php" del ejercicio 21.

El "test_server.php" en su respuesta debe incluir un campo donde aparezca la suma del "operando1" y el "operando2".
