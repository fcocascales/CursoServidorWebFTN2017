Ejercicio 14
============

Lo mismo que el ejercicio 13 usando AJAX.

  - Nada de PHP, sólo Javascript.
  - La página será HTML
  - Usar jQuery para AJAX
  - Los datos provienen de los JSON del ejercicio 12
  - No necesita formulario, no se envía ningún formulario, la página sólo se carga la primera vez.

## Enlaces

  - [Curso de jQuery](https://pablomonteserin.com/cursos/web/javascript/jquery/) por Pablo Monteserín
