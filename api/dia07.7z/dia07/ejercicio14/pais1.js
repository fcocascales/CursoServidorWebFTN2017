/*
  pais1.js

  Comprobar que funciona jQuery con
  muy poco código.

  jQuery es el $
*/

$(init);

function init() {
  alert('Hola jQuery!!!');
}
