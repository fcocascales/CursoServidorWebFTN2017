<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ejercicio 13</title>
</head>
<body>
  <h1>Ejercicio 13</h1>
  <p>
    <a href="ejercicio13.md">Enunciado</a>
  </p>
  <h2>Solución</h2>
  <ul>
    <li><a href="pais.php">Ficha del país</a></li>
  </ul>
</body>
</html>
