<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ejercicio 11</title>
</head>
<body>
  <h1>Ejercicio 11</h1>
  <p>
    <a href="ejercicio11.md">Enunciado</a>
  </p>
  <h2>Solución</h2>
  <ul>
    <li><a href="herbivoros.json.php">herbivoros.json.php</a></li>
  </ul>
</body>
</html>
