<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Ejercicio 1</title>
</head>
<body>
	<h1>Ejercicio 1</h1>
	<ul>
		<li><a href="../ejercicio1.md">Enunciado</a></li>
		<li><a href="prueba.php">Prueba</a></li>
		<li><a href="filtro.php">Solución</a></li>
	</ul>
</body>
</html>
