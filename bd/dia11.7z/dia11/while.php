<?php

  /*$i = 10;
  while ($i--) {
    echo $i;
  }*/

  $a = array('a','b','c');
  echo $a[10];
  /*$i = 0;
  while ($c = $a[$i++]) {
    echo $i;
  }*/
