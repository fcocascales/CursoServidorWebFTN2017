INSERT INTO planetas VALUES (1, 'Mercurio', 4878, 58);
INSERT INTO planetas VALUES (2, 'Venus', 12100, 108);
INSERT INTO planetas VALUES (3, 'La Tierra', 12756, 146);
INSERT INTO planetas VALUES (4, 'Marte', 6787, 228);
INSERT INTO planetas VALUES (5, 'Júpiter', 142984, 778);
INSERT INTO planetas VALUES (6, 'Saturno', 120536, 1429);
INSERT INTO planetas VALUES (7, 'Urano', 51108, 2870);
INSERT INTO planetas VALUES (8, 'Neptuno', 49538, 4504);
