phpMyAdmin
==========

Toda tabla tendrá un primer campo llamado **id**
  - Autonumérica o contador o autoincremental
  - Clave primaria

## Recomendaciones para los nombres de tablas y campos

  - Escribir todo en minúsculas
  - No poner acentos
  - No usar espacio en blanco. Usar el _ en su lugar

## Base de datos: bd1

### Tabla: agenda

  - id, int, auto_increment, primary key
  - nombre, varchar(50)
  - telefono, varchar(50), null
  - correo, varchar(50), null
