<?php
  // dominio.php

  echo '$_SERVER["SERVER_NAME"] = '.$_SERVER["SERVER_NAME"];
  echo '<br>';
  echo '$_SERVER["HTTP_HOST"] = '.$_SERVER["HTTP_HOST"];
