<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Ejercicio 3</title>
</head>
<body>
	<h1>Ejercicio 3</h1>
	<ul>
		<!--li><a href="../ejercicio2.md">Enunciado</a></li-->
		<li><a href="prueba.php">Prueba</a></li>
		<li><a href="filtro_form.php">Filtro con formulario</a></li>
		<li><a href="filtro_enlaces.php">Filtro con enlaces</a></li>
		<li><a href="autofiltro_form.php">Autofiltro con formulario</a></li>
		<li><a href="autofiltro_enlaces.php">Autofiltro con enlaces</a></li>
	</ul>
</body>
</html>
