Consultas 3 en bd_neptuno
=========================

## Consultas de repaso

1. Seleccionar el nombre y el precio de todos los productos en cuyo nombre aparece la palabra 'cerveza' o 'queso'. Ordénalo por el nombre.

2. Crea una consulta de unión con los campos: empresa, contacto y teléfono. Usa las tablas: clientes y proveedores. Ordénalo por empresa.

3. Usa la función de concatenación para mostrar la siguiente frase en cada producto: "El producto X es de la categoría Y".

4. Muestra los pedidos de los clientes alemanes realizados por los empleados Nancy o Janet. Ordénalo por cliente, empleado y fecha de pedido.

5. Muestra de cada pedido: el id, la fecha, la compañía de envío y el total. Para calcular el total hay que sumar las líneas de detalle correspondientes.
