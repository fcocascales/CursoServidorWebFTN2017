<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Era Mesozoica</title>
</head>
<body>
  <h1>Era Mesozoica</h1>
  <ul>
    <li><a href="listado.php">Lista de dinosaurios</a></li>
    <li><a href="insertar.php">Añadir un nuevo dinosaurio</a></li>
  </ul>
</body>
</html>
