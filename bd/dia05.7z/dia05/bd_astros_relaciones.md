Ejercicio de consultas con 2 tablas
===================================

Realiza las siguientes consultas y fíjate en el número de filas que aparecen en cada ocasión.

  1. Mostrar el nombre de los planetas y el nombre de los satélites en un producto cartesiano. **cross join**
  2. Mostrar el nombre de los planetas que tengan satélites y el nombre de éstos. **inner join**
  3. Mostrar el nombre de todos los planetas y el nombre de sus satélites correspondientes. **left|right join**
  4. Mostrar una lista con el nombre y el diámetro de todos los planetas y de todos los satélites indicando si se trata de un planeta o de un satélite. Ordénalo por el nombre. **union**
