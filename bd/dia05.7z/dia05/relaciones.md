Relaciones entre tablas
=======================

Crea una BD nueva llamada **bd_relaciones** con las siguientes tablas:

## personas
|id | nombre |
|---|--------|
| 1 | Pepe   |
| 2 | Ana    |
| 3 | Joan   |
| 4 | Bea    |
| 5 | Carlos |
| 6 | Pili   |

## mascotas
|id | nombre | persona_id |
|---|--------|------------|
| 1 | Pluto  |    4       |
| 2 | Satán  |    5       |
| 3 | Yaki   |    3       |
| 4 | Tor    |    3       |
| 5 | Piolín |    NULL    |
