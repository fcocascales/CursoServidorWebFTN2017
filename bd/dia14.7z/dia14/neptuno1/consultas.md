Consultas en bd_neptuno
=======================

## Consultas con filtros

  1. Mostrar los clientes de Alemania
  2. Mostrar los clientes de Alemania y Francia
  3. Mostrar los clientes cuya empresa empiezan por la letra B
  4. Productos que cuestan entre 20 y 30 euros
  5. Productos de la categoría "Pescado/Marisco"
  6. Clientes que no tienen fax
  7. Pedidos realizados en julio de 1996 a Brasil
  8. Pedidos realizados por la empleada Nancy en mayo de 1998
  9. Productos del proveedor 'Tokyo Traders' que cuestan menos de 50 euros.
  10. Pedidos a clientes de Alemania por la compañía de envío 'Speedy Express'.
