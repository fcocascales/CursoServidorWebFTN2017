<?php
  require_once "backend.php";
  desconectar_usuario();
?>
