<?php


?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Prohibido</title>
  <style media="screen">
    body { background-color:#f99; }
  </style>
</head>
<body>
  <h1>Acceso denegado</h1>
  <p><a href="login.php">Conectar</a></p>
</body>
</html>
