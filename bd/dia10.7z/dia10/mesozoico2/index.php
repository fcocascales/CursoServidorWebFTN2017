<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Era Mesozoica</title>
</head>
<body>
  <h1>Era Mesozoica</h1>
  <h2>Versión 2</h2>
  <ul>
    <li><a href="listado.php">Lista de dinosaurios</a></li>
  </ul>
</body>
</html>
