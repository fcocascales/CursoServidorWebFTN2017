<?php header("Location: factorizacion.php"); ?>
