Web applications
----------------

DIRECTO:  BD --php--> HTML

API REST: BD --php--> JSON --php--> HTML

API REST: BD --php--> XML  --php--> HTML

AJAX:     BD --php--> JSON --javascript--> HTML
