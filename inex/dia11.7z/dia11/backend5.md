Backend
=======

Empezar el Backend

El backend será una carpeta dentro del frontend

## Carpetas

  - frontend
    - backend

## Dominios

  - Frontend: http://thor.com/ - En un carpeta
  - Backend:  http://thor.com/backend - fotos no hay problema
  - Backend:  http://backend.thor.com/ - es complicado acceder a las fotos

## Diseño
  - Encabezado
  - Navegador
  - Contenido

## Gestor de contenidos de productos
  - Listar productos
  - Insertar nuevo
  - Borrar existente
  - Modificar existente

## Otros gestores de contenidos
  - Categorías
  - Slider
  - Preguntas frecuentes
  - Redes sociales
  - Indicar productos destacados
  - Noticias
  - Comentarios a los productos

## Pasos a seguir

  1. Crear la subcarpeta **backend**
  2. Copiar **dia06/login** dentro del backend
  
