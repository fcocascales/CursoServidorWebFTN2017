UPDATE categorias SET categoria = 'Verduras' WHERE categoria = 'Frutas/Verduras';
UPDATE categorias SET categoria = 'Cereales' WHERE categoria = 'Granos/Cereales';
UPDATE categorias SET categoria = 'Pescado' WHERE categoria = 'Pescado/Marisco';
