<?php
  require_once "autorizacion.php";

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Backend</title>
</head>
<body>
  <h1>Backend</h1>
  <p><?php echo "¡Hola $nombre!" ?></p>
  <p><a href="logout.php">Desconectar</a></p>
</body>
</html>
