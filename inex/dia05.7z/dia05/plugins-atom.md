Plugins de Atom.io
==================

Mostrar "settings" CTROL ,

- EMMET - Atajos de teclado para HTML y CSS

- LINTER - Muestra los errores al codificiar en un lenguaje de programación
- LINTER PHP
