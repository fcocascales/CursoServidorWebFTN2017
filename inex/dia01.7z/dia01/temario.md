Temario
=======

  - Base de datos: SQL, PDO
  - Una web con dos zonas:
    - pública -
    - privada - (intranet o extranet)
  - CMS - Gestor de contenidos
    - Listar el contenido de una tabla de la BD
    - Poder hacer inserciones, actualizaciones y borrados
  - Plantillas en PHP
  - Una web multiidioma
  * Paginación de los resultados
  * Subir ficheros al servidor mediante formulario
  - Autenticación para entrar en la zona privada
  * Usar AJAX (Javascript, jQuery, JSON, DOM)
  * Proyecto personal de una web
