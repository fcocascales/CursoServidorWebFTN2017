<?php
  $title = "Thor";
  $keywords = "thor, alimento, comida, catálogo";
  $description = "Catálogo de productos alimenticios de primera calidad"; // 150 carácteres
  $extra = ""; // Opcional: Incluir CSS o Javascript sólo para esta página
  $include = "slider/slider.php"; // Opcional
  include "template/head.php";
?>
<!--
  Aquí va el contenido principal de esta página
-->
<?php
  include "template/foot.php";
?>
