<section id="slider">
  <img src="img/slider1.jpg" width="800" height="200">
</section>
