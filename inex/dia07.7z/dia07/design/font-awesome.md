Font Awesome - The iconic font and CSS toolkit
============

Poner iconos de un sólo color.
Escalan muy bien porque es una fuente.

## Enlaces

 - [principal](http://fontawesome.io/)
 - [Ver los iconos](http://fontawesome.io/icons/)

## Instalación

Download

Descomprimir en una carpeta llamada "fa"

  - fa
    - css
    - fonts
    - less
    - scss

## Uso    

1) Añadir un enlace al archivo CSS  

`<link rel="stylesheet" href="fa/css/font-awesome.min.css">`

2) Añadir los iconos de las redes sociales

    <li><a href="#"><i class="fa fa-facebook-square"></i> Facebook</a></li>
    <li><a href="#"><i class="fa fa-twitter"></i>         Twitter</a></li>
    <li><a href="#"><i class="fa fa-pinterest"></i>       Pinterest</a></li>
    <li><a href="#"><i class="fa fa-instagram"></i>       Instagram</a></li>
    <li><a href="#"><i class="fa fa-youtube-play"></i>    YouTube</a></li>
    <li><a href="#"><i class="fa fa-linkedin-square"></i> LinkedIn</a></li>
    <li><a href="#"><i class="fa fa-rss"></i>             Feed</a></li>
