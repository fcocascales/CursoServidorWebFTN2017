Plantillas para el Frontend y Backend
=====================================

## Plantilla para el Frontend

  - HTML
    - HEAD
      - META
      - TITLE
      - SCRIPT
      - LINK
    - BODY
      - DIV
        - HEADER
          - IMG#LOGO
          - H1, H2
          - BUSCADOR
          - SLIDER
          - NAV
        - MAIN
          - SECTION
            - ARTICLE
        - FOOTER
          - NAV
