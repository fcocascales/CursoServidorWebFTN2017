Backend 9
=========

## Realizar el examen teórico y práctico
 


## Repositorios con los ejercicios de clase:

 - [Google drive](http://goo.gl/JcfWHb)
 - [GitHub](https://github.com/fcocascales/CursoServidorWebFTN2017)
 - [Foment](http://fcascales.fomentformacio.tech)
