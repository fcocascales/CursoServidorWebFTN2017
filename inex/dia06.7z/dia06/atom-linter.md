Plugin Linter de Atom.io
========================

**LINTER** = Muestra los errores de PHP (o de otros lenguajes) antes incluso de mostrar la página en el navegador web.

Instalación:

1. Arrancar el Atom
2. File > Settings
3. Install y buscar "linter php"
  - Instalar "linter" y todo lo que sugiera
  - Instalar "linter-php"
4. Configurar el "linter-php" > Settings
  - PHP executable path = `C:\xampp\php\php.exe`
