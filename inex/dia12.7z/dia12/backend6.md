Backend 6
=========

## Crear la plantilla

- Copiar la plantilla del frontend y cambiarla
- Crear el fichero "css/styles.css" con una importación a "backend.css"

## Crear un gestor de contenidos de productos

Estructura de carpetas y archivos:
  - backend/
    - productos/ —
      - index.php —
      - insertar.php, insertado.php —
      - modificar.php —
      - borrar.php —
