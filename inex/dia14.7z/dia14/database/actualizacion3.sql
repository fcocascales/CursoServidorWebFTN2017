ALTER TABLE categorias
  ADD activado BOOLEAN DEFAULT TRUE;
