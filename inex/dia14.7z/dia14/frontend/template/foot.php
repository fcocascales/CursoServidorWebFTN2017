</main>
<footer id="pagefooter">
  <nav id="menu">
    <ul>
      <li><a href="#">Últimas noticias</a></li>
      <li><a href="#">Formulario de contacto</a></li>
      <li><a href="#">Dónde encontrarnos</a></li>
      <li><a href="#">Respuestas a preguntas frecuentes</a></li>
    </ul>
  </nav>
  <nav id="social">
    <ul>
      <li><a id="facebook"  href="#"><i class="fa fa-facebook-square"></i> Facebook</a></li>
      <li><a id="twitter"   href="#"><i class="fa fa-twitter"></i> Twitter</a></li>
      <li><a id="pinterest" href="#"><i class="fa fa-pinterest"></i> Pinterest</a></li>
      <li><a id="instagram" href="#"><i class="fa fa-instagram"></i> Instagram</a></li>
      <li><a id="youtube"   href="#"><i class="fa fa-youtube-play"></i> YouTube</a></li>
      <li><a id="linkedin"  href="#"><i class="fa fa-linkedin-square"></i> LinkedIn</a></li>
      <li><a id="feed"      href="#"><i class="fa fa-rss"></i> Feed</a></li>
    </ul>
  </nav>
</footer>
</div>
</body>
</html>
