<?php
$categoria = strip_tags(trim($_POST['categoria']));
$descripcion = strip_tags(trim($_POST['descripcion']));
$activado = isset($_POST['activado']);
