<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Blog</title>
</head>
<body>
	<h1>Inicio del Blog</h1>

	<p>El nombre es <?= $nombre ?></p>
	<p>El teléfono es <?= $telefono ?></p>

</body>
</html>
