$(function() {

	$('#toggle_nav').click(function() {
		$(this).next().slideToggle();
	});


});
