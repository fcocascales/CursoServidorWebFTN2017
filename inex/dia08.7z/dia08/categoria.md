Realizar la página de categoría
===============================

"frontend/categoria.php"

## Categoría (arriba de la página)

  - Marcar en el menú la categoría actual.
    Si la URL es `categoria.php?id=1` entonces cambiar el color de la categoría "Bebidas".
  - Mostrar una foto representativa de la categoría colocada donde estaba el slider.
    - /frontend/img/categorias/1.jpg, 2.jpg, 3.jpg, 4.jpg, etc.
    - El tamaño es de 800x200 píxeles.
  - Mostrar el texto de la descripción de la categoría. Está en la BD.

## Productos de la categoría  (el contenido de la página)

  - Mostrar 6 productos por página.
  - Filtrar por rangos de precio.
  - Filtrar por proveedor.
  - Ordenar por precio ascendente o descendente. Ordenar por producto.
