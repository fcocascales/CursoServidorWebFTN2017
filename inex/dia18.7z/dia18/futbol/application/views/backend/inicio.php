<h2>Enlaces</h2>
<ul>
  <li><a href="<?= site_url() ?>/noticias">Gestor de noticias</a></li>
</ul>

<h2>Funciones del helper url</h2>
<ul>
  <li>base_url: <code><?= base_url() ?></code></li>
  <li>site_url: <code><?= site_url() ?></code></li>
</ul>
