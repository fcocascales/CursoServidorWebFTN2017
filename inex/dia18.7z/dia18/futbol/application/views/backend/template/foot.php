</main>
<footer>
  <hr>
  <p>&copy; 2017</p>
</footer>
</body>
</html>
