<?php

  //=============================================
  // ENCABEZADO DE PÁGINA

  $title = "Thor";
  $keywords = "thor, alimento, comida, catálogo";
  $description = "Catálogo de productos alimenticios de primera calidad"; // 150 carácteres
  $extra = '<link rel="stylesheet" href="mod/slider/styles.css">';
  $include = "mod/slider/include.php";
  include "template/head.php";

  //=============================================
  // CUERPO DE PÁGINA

  // ...
  // TODO: Mostrar los N productos más destacados
  // ...

  //=============================================
  // PIE DE PÁGINA

  include "template/foot.php";
