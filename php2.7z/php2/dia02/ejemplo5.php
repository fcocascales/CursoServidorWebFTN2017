<?php
  // Ejemplo 5: Concatenación

  $capital = "París";
  $pais = "Francia";
  $moneda = "euro";
  $poblacion = 66000000;

  // Imprimir lo siguiente:
  //    La capital de Francia es París,
  //    su moneda es el euro y tiene 66000000 de habitantes

  echo "La capital de $pais es $capital, su moneda es el $moneda y tiene $poblacion de habitantes<br>";

  echo "La capital de ".$pais." es ".$capital.", su moneda es el ".$moneda." y tiene ".$poblacion." de habitantes<br>";


 ?>
