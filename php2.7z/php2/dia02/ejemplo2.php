<?php

  // Variables
  // Firefox: localhost/php2

  // La variable $nombre es un texto (string)
  // y le asigno Pepe. Pepe es un literal
  // y tiene que ir entrecomillado.

  $nombre = "Pepe";
  $telefono = "93-567-90-01";

  // Imprimir las Variables

  echo $nombre;
  echo " ";
  echo $telefono;

?>
