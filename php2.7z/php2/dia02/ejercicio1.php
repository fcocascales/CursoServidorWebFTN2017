<?php
  /*
    Inicializar una variable numérica

    Imprimir positivo, o negativo o cero.
  */

  $numero = -6;

  if ($numero > 0)
  {
      echo "$numero es positivo";
  }
  elseif ($numero < 0)
  {
      echo "$numero es negativo";
  }
  else
  {
      echo "$numero es cero";
  }


 ?>
