<?php

  $numero = 101;
  echo "Empieza el programa<br>";
  if ($numero > 100)
  {
      echo "El $numero es mayor que 100<br>";
  }
  echo "Fin del programa<br>";

?>
