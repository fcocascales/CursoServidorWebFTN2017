<?php

  // http://localhost/php2/dia02/ejemplo1.php

  // Un programa escrito en el lenguaje php
  // Este programa está compuesta de 4 instrucciones
  // Cada instrucción finaliza en un ;

  // Inicializar las variables $a y $b
  // El operador = es una asignación
  // La asignación almacena un valor en la variable

  $a = 2;
  $b = 10;

  // Imprimir las variables

  echo $a;
  echo $b;

 ?>
