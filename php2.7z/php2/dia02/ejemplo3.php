<?php
  /*
    Inicializar 2 variables globales
    asignandoles un valor a cada una.
  */
  $operando1 = 5;
  $operando2 = 12;

  // Operadores aritméticos

  // Las instrucciones se ejecutan secuencialmente
  //  una tras otra

  echo "Sumar las variables ";
  echo $operando1 + $operando2;
  echo "<br>";
  echo "Restar las variables ";
  echo $operando1 - $operando2;
  echo "<br>";
  echo "Multiplicar las variables ";
  echo $operando1 * $operando2;
  echo "<br>";
  echo "Dividir las variables ";
  echo $operando1 / $operando2;










 ?>
