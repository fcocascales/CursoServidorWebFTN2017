<?php

  // Comentario de una línea

  /*
    Comentario de
    varias líneas
  */

  echo "<h1>Prueba tres</h1>";

  echo 2 / 7 + 5;

?>
