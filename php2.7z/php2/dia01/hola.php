<?php

  echo "Mi primera página en PHP";

  echo "<br>";

  echo 2+3*4;

 ?>
