Ejercicio 1
===========

  - Crear la página "hola.html" en un editor de textos.
  Y guardarla aquí: `C:\xampp\htdocs\php2\dia01\hola.html`

  - En el navegador web:  http://localhost/php2/dia01/hola.html

  - En el navegador web: *Ver el código fuente*
