<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Prueba 4</title>
  </head>
  <body>
    <h1>Prueba 4</h1>
    <p><?php echo 4*(2+3); ?></p>
  </body>
</html>
