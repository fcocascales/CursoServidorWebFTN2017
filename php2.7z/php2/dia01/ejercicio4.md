Ejercicio 4
===========

Imprimir la tabla de multiplicar del 9.
Con un bucle for. Debería ser fácil cambiar de tabla de multiplicar.
El fichero se llamará "tabla.php"

    1 x 9 = 9
    2 x 9 = 18
    3 x 9 = 27
    ...
    9 x 9 = 81
    10 x 9 = 90
