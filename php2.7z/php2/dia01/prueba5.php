<?php

  $titulo = "Este es el título de la web";

 ?><!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $titulo; ?></title>
  </head>
  <body>
    <h1><?php echo $titulo; ?></h1>
  </body>
</html>
