<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Día 1</title>
</head>
<body>
  <h1>Día 1</h1>
  <ul>
    <li><a href="presentacion.md">presentacion.md</a></li>
    <li><a href="programas.md">programas.md</a></li>
    <li><a href="xampp.md">xampp.md</a></li>
    <li><a href="servidor.md">servidor.md</a></li>
    <li><a href="ejercicio1.md">ejercicio1.md</a></li>
    <li><a href="hola.html">hola.html</a></li>
    <li><a href="ejercicio2.md">ejercicio2.md</a></li>
    <li><a href="hola.php">hola.php</a></li>
    <li><a href="ejercicio3.md">ejercicio3.md</a></li>
    <li><a href="prueba3.php">prueba3.php</a></li>
    <li><a href="prueba4.php">prueba4.php</a></li>
    <li><a href="prueba5.php">prueba5.php</a></li>
    <li><a href="bucle1.php">bucle1.php</a></li>
    <li><a href="bucle2.php">bucle2.php</a></li>
    <li><a href="bucle3.php">bucle3.php</a></li>
    <li><a href="ejercicio4.md">ejercicio4.md</a></li>
    <li><a href="tabla.php">tabla.php</a></li>
  </ul>
</body>
</html>
