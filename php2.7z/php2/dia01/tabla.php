<?php

  // Tabla de multiplicar del 9

  $tabla = 9;

  // Este bucle se repite 10 veces
  // la primera vez la variable $i vale 1
  // después vale 2, ... y la última vez vale 10
  for ($i=1; $i<=10; $i++) {
    echo $i;
    echo " x ";
    echo $tabla;
    echo " = ";
    echo $i * $tabla;
    echo '<br>';
  }





 ?>
