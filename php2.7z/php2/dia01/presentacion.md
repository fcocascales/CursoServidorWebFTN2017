Desarrollo de aplicaciones web en el servidor
==============================================

Docente:
- Francisco Cascales
- fco@proinf.net
- proinf.net/noticias o /proyectos

Curso:
  - 90 horas (23 días)
  - martes y jueves de 18:00 a 22:00 (4 horas)
  - descanso a las 20:00 (15 min)

Relación:
  - Navegar por Internet
  - HTML, CSS, Javascript
  - FTP

Lugar dónde almacenar los ficheros del curso:
  - `C:\xampp\htdocs\php2`
  - `C:\xampp\htdocs\php2\dia01`



  
