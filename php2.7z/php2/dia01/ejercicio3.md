Ejercicio 3
===========

Crea una página PHP llamada "prueba3.php" que imprima lo siguiente:
  - Un título H1 que ponga: *Prueba tres*
  - El resultado de la operación: 2/7+5

Guardar la página, probarla en el navegador web y mirar el código fuente.  
