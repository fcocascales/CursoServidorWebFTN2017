Introducción
============

## Programas

Editor de textos:
  - Notepad++ (Windows)
  - Geany (Multiplatorma)
  - Sublime (licencia 70$)
  * Atom.io (software libre)

Navegador web:
  * Mozilla Firefox
  - Google Chrome
  - Microsoft Edge (Internet Explorer)  
  - Safari
  - Opera (Vivaldi)

Servidor web:
  * Apache
  - Microsoft IIS (Internet Information Server)
  - Nginx

Lenguaje de programación en el servidor web:
  * PHP
  - Python
  - Java
  - Ruby
  - .NET C#, Visual Basic

Base de datos en el servidor web:
  * MySQL, MariaDB
  - SQLite
  - Microsoft SQL Server
  - Oracle
  - MongoDB
  - HADOOP (big data)

FTP Transferencia de ficheros
  * FileZilla Cliente FTP

Paquete de programas:
  - [XAMPP](http://xampp.org) - Apache, MySQL, PHP, Perl
