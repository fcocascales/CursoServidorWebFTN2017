Ejercicio 2
===========

  - Crear la página "hola.php" en un editor de textos.
  Y guardarla aquí: `C:\xampp\htdocs\php2\dia01\hola.php`

  - En el navegador web:  http://localhost/php2/dia01/hola.php

  - En el navegador web: *Ver el código fuente*
