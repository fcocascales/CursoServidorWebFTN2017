<?php

  $frase = 'Este es el bucle tres';
  $cuenta = 77;

  /*
    En un texto entre comillas dobles
    se pueden poner variables.
  */

  for ( $i = 0 ; $i < $cuenta ; $i++ ) {
    echo "$i) $frase<br>" ;
  }

?>
