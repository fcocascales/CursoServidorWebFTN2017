XAMPP
=====

**Apache** + MariaDB + **PHP** + Perl

  1. Iniciar el panel de control de XAMPP

    `C:\xampp\xampp-control.exe`

    Arrancar el Apache.
    Ahora tenemos un servidor web en nuestra propia máquina.

  2. Acceder a mi servidor web:

    En el navegador web: http://localhost

    Acceder a mi carpeta: http://localhost/php2

    La dirección de mi carpeta en el disco duro:
      `C:\xampp\htdocs\php2`

    *Apache/2.4.25 (Win32) OpenSSL/1.0.2j PHP/5.6.30 Server at localhost Port 80*
