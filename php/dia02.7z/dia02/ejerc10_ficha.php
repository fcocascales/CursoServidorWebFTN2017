<?php

  $id = intval($_GET['id']);

?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Ejercicio 10 ficha</title>
</head>
<body>
<h1>Ejercicio 10 ficha</h1>

<p><img src="<?php echo $id; ?>.jpg"></p>

<p><a href="ejerc10.php">Volver</a></p>

</body>
</html>
