<?php  $a = 100;
  $b = 200;

?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Ejercicio 1</title>
</head>
<body>
<h1>Ejercicio 1</h1>

<p>Sumar las variables a y b</p>
<div><?php echo $a + $b; ?></div>

<p>Restar las variables a y b</p>
<div><?php echo $a - $b; ?></div>

<p>Multiplicar las variables a y b</p>
<div><?php echo $a * $b; ?></div>

<p>Dividir las variables a y b</p>
<div><?php echo $a / $b; ?></div>

</body>
</html>
