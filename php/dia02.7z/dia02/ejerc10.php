<?php

?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Ejercicio 10</title>
</head>
<body>
<h1>Ejercicio 10</h1>
<ul>
  <li><a href="ejerc10_ficha.php?id=1">Primero</a></li>
  <li><a href="ejerc10_ficha.php?id=2">Segundo</a></li>
  <li><a href="ejerc10_ficha.php?id=3">Tercero</a></li>
</body>
</html>
