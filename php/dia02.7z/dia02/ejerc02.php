<?php
  $a = 50;
  $b = 1000;

?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Ejercicio 2</title>
</head>
<body>
<h1>Ejercicio 2</h1>
<?php
  echo "<p>La suma de ".$a." y de ".$b." es ".($a+$b)."</p>\n";
  echo "<p>La resta de ".$a." y de ".$b." es ".($a-$b)."</p>\n";
  echo "<p>La multiplicación de ".$a." y de ".$b." es ".($a*$b)."</p>\n";
  echo "<p>La división de ".$a." y de ".$b." es ".($a/$b)."</p>\n";
?>

</body>
</html>
