<?php
  $titulo = "Tres colores";
  $activo = "Tres";
  include "cabeza.php";
?>
<h2>Ejemplo tres</h2>
<p>Más cosas interesantes.</p>
<p>Otro párrafo</p>
<?php include "pie.php" ?>
