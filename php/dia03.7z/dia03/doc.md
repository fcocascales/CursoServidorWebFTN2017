Documentación de PHP
====================

Sitio oficial de PHP:
  http://php.net

  Documentation > Español
    - Referencia del lenguaje

Sitio de aprendizaje:
  http://w3schools.com

Página de información de PHP:
  <?php phpinfo(); ?>
