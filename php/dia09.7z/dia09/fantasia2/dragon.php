<?php
  include "autorizacion.php";
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dragón</title>
</head>
<body>
  <h1>Dragón</h1>
  <p><img src="imgs/dragon.jpg"></p>
  <p><a href="clave.php">Introducir la clave</a></p>
</body>
</html>
