<?php
  include "autorizacion.php";
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Unicornio</title>
</head>
<body>
  <h1>Unicornio</h1>
  <p><img src="imgs/unicornio.jpg"></p>
  <p><a href="clave.php">Introducir la clave</a></p>
</body>
</html>
