<?php
  include "autorizacion.php";
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Centauro</title>
</head>
<body>
  <h1>Centauro</h1>
  <p><img src="imgs/centauro.jpg"></p>
  <p><a href="clave.php">Introducir la clave</a></p>
</body>
</html>
