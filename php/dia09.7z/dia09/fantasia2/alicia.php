<?php
  include "autorizacion.php";
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Alicia</title>
</head>
<body>
  <h1>Alicia</h1>
  <p><img src="imgs/alicia.jpg"></p>
  <p><a href="clave.php">Introducir la clave</a></p>
</body>
</html>
