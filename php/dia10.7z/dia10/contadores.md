Ejercicio contadores
====================

Crea una página llamada "contadores.php".
En ella hay que poner 4 contadores de visitas:

  - Un contador con una variable global php.
  - Un contador con una variable de sesión.
  - Un contador con una variable en una cookie.
  - Un contador dentro de un fichero de texto.

Al refrescar la página cada contador se ha de incrementar en una unidad. Si el contador no existe se ha de crear con un valor inicial de 0.

Explica hasta dónde puede llegar la cuenta como máximo en cada tipo de contador.  
