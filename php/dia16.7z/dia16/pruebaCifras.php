<?php

  require_once "CifrasEnLetras.php";

  $numero = 1234567890;

  echo CifrasEnLetras::convertirNumeroEnLetras($numero);

 ?>
