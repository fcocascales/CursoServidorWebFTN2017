<?php
  require_once "locale.php";
  Locale::set();
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo _('Página dos') ?></title>
</head>
<body>
  <h1><?php echo _('Página dos') ?></h1>
  <p><a href="."><?php echo _('Volver al inicio') ?></a></p>
</body>
</html>
