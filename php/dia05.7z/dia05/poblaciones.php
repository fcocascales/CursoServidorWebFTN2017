<?php

  $poblaciones = array(
    'Martorell', 'Granollers', 'Sabadell',
    'Terrassa', 'Mataró', 'Sant Boi',
  );
  sort($poblaciones);
