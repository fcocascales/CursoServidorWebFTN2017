Ejercicio
---------

Crea la clase **Rango**.
   - Tiene dos atributos privados llamados *min* y *max*.
   - Tiene un constructor para inicializar los 2 atributos.  
   - Tiene un método *contiene* donde se le pasa un valor y da true cuando el valor está comprendido entre el valor mínimo y el valor máximo.

Crea un par de **objetos** de la clase Rango y usa el método *contiene* dentro de un if para mostrar un mensaje en pantalla.
