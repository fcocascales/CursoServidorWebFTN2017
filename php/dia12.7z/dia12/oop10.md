Ejercicio
---------

La clase **Animales** tiene los siguientes atributos:
  - Especie
  - Número de animales
  - Procedencia  
La clase tendrá un constructor.
La clase tendrá 3 métodos get por cada uno de los atributos.

Crear un array llamado **zoo** de los Animales.
Imprimir el array.
