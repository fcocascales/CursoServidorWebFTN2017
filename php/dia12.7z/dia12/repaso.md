Programación Orientada a Objetos
================================

  Los *atributos* siempre son privados.

  Los métodos *get* se utilizan para obtener el valor de un atributo.

  Los métodos *set* se utilizan para modificar el valor de un atributo.

  Ejemplo:
    private $edad;
    public getEdad() { return $this->edad; }
    public setEdad($valor) { $this->edad = $valor; }
