<?php 

echo '<!DOCTYPE html>';
echo '<html>';
echo '<head>';
echo '<meta charset="utf-8" />';
echo '<title>Cuatro</title>';
echo '</head>';
echo '<body>';
echo '<h1>Cuatro</h1>';
echo '</body>';
echo '</html>';

?>