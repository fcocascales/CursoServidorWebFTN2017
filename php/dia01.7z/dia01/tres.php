<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title><?php echo 1+2; ?></title>
</head>
<body>
<h1><?php echo "Tres"; ?></h1>
</body>
</html>