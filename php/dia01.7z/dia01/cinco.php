<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Bucle</title>
</head>
<body>
<h1>Bucle</h1>
<?php

	for($i=0; $i<5000; $i++) {
		echo $i;
		echo "<br>";
	}

?>
</body>
</html>