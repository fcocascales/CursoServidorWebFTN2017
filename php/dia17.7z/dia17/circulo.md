Ejercicio de POO
================

Crea la clase Circulo en el archivo "Circulo.php".

## Contenido de la clase

  - Constantes: PI
  - Atributos: radio
  - Constructor: Con el parámetro radio
  - Métodos SET: setRadio
  - Métodos GET:
    - getRadio
    - getCircunferencia
    - getArea

## Prueba de la clase

Crea un archivo llamado "testCirculo.php". Crea un objeto de la clase Circulo. Prueba todos sus métodos.
