<?php

// La tabla agenda es un array de arrays

$agenda = array(
  array('nombre'=>"Pepe",  'telefono'=>"123-45-67", 'correo'=>"pepe@gmail.com"),
  array('nombre'=>"Ana",   'telefono'=>"555-67-80", 'correo'=>"ana@mail.com"),
  array('nombre'=>"Joan",  'telefono'=>"678-78-78", 'correo'=>"joan@email.net"),
  array('nombre'=>"Marc",  'telefono'=>"901-93-90", 'correo'=>"marc@correo.es"),
  array('nombre'=>"Marta", 'telefono'=>"444-22-33", 'correo'=>"marta@acme.com"),
);
