Base de datos simulada con arrays
=================================

Estructura de módulos:

	- BaseDatos.php       - Referencias a la tablas agenda y almacen
		- TablaAgenda.php   - Array de contactos
		- TablaAlmacen.php  - Array de productos

Archivos de la web:

	- Tienda.php   - Formulario para compra
	- Comprar.php  - Realizar la compra
