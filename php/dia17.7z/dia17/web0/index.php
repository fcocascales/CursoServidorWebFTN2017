<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>BD0</title>
</head>
<body>
	<h1>Base de datos simulada nº0</h1>
	<p>
		La agenda y el almacen son arrays indexados.
		<br>Los contactos y productos son arrays asociativos.
	</p>
	<ul>
		<li><a href="tienda.php">Comprar en la tienda</a></li>
		<li><a href="../../markdown.php?md=dia17/web0/bd0.md">Apuntes</a></li>
		<li><a href="pruebaBD.php">Ver BD</a></li>
	</ul>
</body>
</html>
