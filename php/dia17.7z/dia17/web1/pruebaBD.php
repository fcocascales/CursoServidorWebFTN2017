<?php

  require_once "BaseDatos.php";

  echo "<h1>Base de datos</h1>";
  echo "<pre>";

  echo "<h2>Agenda de contactos</h2>";
  print_r($agenda);

  echo "<h2>Almacen de productos</h2>";
  print_r($almacen);

 ?>
