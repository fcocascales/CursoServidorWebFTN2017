<?php

  // BaseDatos.php
  //
  // Base de datos simulada
  // Una BD es un conjunto de tablas

  require_once "TablaAgenda.php";
  require_once "TablaAlmacen.php";
