<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>BD2</title>
</head>
<body>
	<h1>Base de datos simulada nº2</h1>
	<p>
		Modelo / Vista / Controlador
		<br>La agenda y el almacen son clases.
		<br>Los contactos y productos son clases.
	</p>
	<ul>
		<li><a href="vista/tienda.php">Comprar en la tienda</a></li>
		<li><a href="../../markdown.php?md=dia17/web2/bd2.md">Apuntes</a></li>
		<li><a href="pruebaBD.php">Ver BD</a></li>
	</ul>
</body>
</html>
