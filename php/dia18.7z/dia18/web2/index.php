<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Excepciones</title>
</head>
<body>
<h1>Excepciones</h1>
<ul>
	<li><a href="excepcion1.php">excepcion1.php</a> &mdash; Lanzar una excepción a través de funciones</li>
	<li><a href="excepcion2.php">excepcion2.php</a> &mdash; Mostrar mensajes al entrar y salir en cada función</li>
	<li><a href="excepcion3.php">excepcion3.php</a> &mdash; Capturar la excepción en el programa principal</li>
	<li><a href="excepcion4.php">excepcion4.php</a> &mdash; Capturar la excepción en una función</li>
	<li><a href="excepcion5.php">excepcion5.php</a> &mdash; Capturar la excepción y volverla a lanzar</li>
	<li><a href="excepcion6.php">excepcion6.php</a> &mdash; Uso de finally para ejecutar siempre un código final</li>
	<li><a href="excepcion7.php">excepcion7.php</a> &mdash; No se puede capturar una división entre cero</li>
	<li><a href="excepcion8.php">excepcion8.php</a> &mdash; Capturar distintas excepciones heredadas de Exception</li>
</ul>
</body>
</html>
