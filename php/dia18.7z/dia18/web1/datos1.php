<?php

  $datos1 = array(
    array("Mates", 15, 40),
    array("Música", 20, 120),
    array("Filosofía", 18, 90),
    array("Gimnasia", 22, 60),
    array("Lengua", 17, 100),
  );  
