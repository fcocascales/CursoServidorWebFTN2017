<?php

  $datos2 = array(
    array('curso'=>"Mates", 'alumnos'=>15, 'horas'=>40),
    array('curso'=>"Música", 'alumnos'=>20, 'horas'=>120),
    array('curso'=>"Filosofía", 'alumnos'=>18, 'horas'=>90),
    array('curso'=>"Gimnasia", 'alumnos'=>22, 'horas'=>60),
    array('curso'=>"Lengua", 'alumnos'=>17, 'horas'=>100),
  );  
