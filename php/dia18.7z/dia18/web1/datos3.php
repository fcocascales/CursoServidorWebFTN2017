<?php

  require_once "Curso.php";

  $datos3 = array(
    new Curso("Mates", 15, 40),
    new Curso("Música", 20, 120),
    new Curso("Filosofía", 18, 90),
    new Curso("Gimnasia", 22, 60),
    new Curso("Lengua", 17, 100),
  );
